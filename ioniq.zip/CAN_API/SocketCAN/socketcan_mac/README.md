# 현재 미완성 코드임. write가 안먹힘.

# 사용법 - cmake를 이용해 사용.
    Xcode프로젝트를 생성하는 방식으로도 사용 가능
            ->  build $ cmake .. -G Xcode
            ->  생성된 xcodeproject 실행
             (CmakeLists.txt에는 canxsend.c를 socketcanx 실행파일로 빌드하는 코드로 작성되어있다.)


To build use `gcc -o scx test.c`.
